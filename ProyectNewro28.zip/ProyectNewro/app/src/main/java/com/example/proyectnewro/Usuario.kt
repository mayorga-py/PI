package com.example.proyectnewro

data class Usuario(
    val nombre: String="",
    val edad: String=""
)
